# PO Signal Bot V1

Prototipo Android de una app de señales para Pocket Option.

## Incluye
- Interfaz móvil oscura.
- Selección de activo.
- Señal CALL / PUT / SIN SEÑAL.
- Score técnico 0–6.
- Flujo preparado para temporalidad de 1 minuto.

## Importante
Esta V1 es un prototipo de interfaz y flujo. El análisis mostrado por el botón es simulado:
todavía NO está conectado a datos reales de Pocket Option y NO ejecuta operaciones.

La siguiente etapa debe incorporar una fuente de velas autorizada/viable, calcular EMA 9/21,
RSI, MACD y Bollinger sobre datos reales, y registrar resultados para backtesting/demo.
No se incluyen credenciales ni automatización de operaciones.
