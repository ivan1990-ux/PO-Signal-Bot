package com.posignalbot

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

data class Signal(val direction: String, val score: Int, val reasons: List<String>)

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val spinner = findViewById<Spinner>(R.id.assetSpinner)
        val assets = listOf("EUR/USD OTC", "GBP/USD OTC", "USD/JPY OTC", "AUD/USD OTC", "EUR/JPY OTC")
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, assets)

        val signalText = findViewById<TextView>(R.id.signalText)
        val scoreText = findViewById<TextView>(R.id.scoreText)
        val detailsText = findViewById<TextView>(R.id.detailsText)
        val button = findViewById<Button>(R.id.analyzeButton)

        button.setOnClickListener {
            // V1 prototype: this simulates the UI flow only.
            // The live market feed and real indicator calculations are intentionally
            // kept separate and will be connected in the next stage.
            val seed = System.currentTimeMillis() / 60000L
            val score = ((seed % 7).toInt()).coerceIn(0, 6)
            val direction = if (score >= 5) {
                if (seed % 2L == 0L) "CALL" else "PUT"
            } else "SIN SEÑAL"

            signalText.text = direction
            scoreText.text = "Score técnico: $score/6"

            detailsText.text = if (direction == "SIN SEÑAL") {
                "No hay suficientes confirmaciones. Esperar la próxima vela."
            } else {
                "Confirmaciones: EMA 9/21 • RSI • MACD • Bollinger • vela\n" +
                "Entrada prevista: próxima vela de 1 minuto\n" +
                "Aviso: el score no representa una probabilidad garantizada."
            }
        }
    }
}
